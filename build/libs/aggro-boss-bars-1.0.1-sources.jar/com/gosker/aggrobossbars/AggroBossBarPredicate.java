package com.gosker.aggrobossbars;

import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_3222;
import net.totobirdcreations.mobbossbars.MobBossBar;

import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;

/**
 * Mob Boss Bars removes a player from a bar whenever any registered predicate
 * returns true. This predicate returns true while a configured mob has no live
 * attack target, with an optional short linger after combat ends.
 */
public final class AggroBossBarPredicate implements MobBossBar.Predicate {
    private final AggroBossBarsConfig config;

    // Weak keys allow unloaded entities and their cached combat state to be collected.
    // Each entity's state is evaluated at most once per world tick, regardless of how
    // many tracking players Mob Boss Bars checks that tick.
    private final Map<class_1297, AggroState> states = new WeakHashMap<>();

    public AggroBossBarPredicate(AggroBossBarsConfig config) {
        this.config = config;
    }

    @Override
    public boolean appliesTo(class_1297 entity) {
        return entity instanceof class_1308 && config.appliesTo(entity);
    }

    @Override
    public boolean hideFromPlayer(class_1297 entity, class_3222 player) {
        if (!(entity instanceof class_1308 mob)) {
            return false;
        }

        long currentTick = entity.method_37908().method_8510();
        AggroState state = states.computeIfAbsent(entity, ignored -> new AggroState());

        if (state.evaluatedTick != currentTick) {
            refreshState(mob, state, currentTick);
        }

        if (!state.visible) {
            return true;
        }

        return shouldHideFromNonTargetedPlayer(player, state.targetPlayerUuid);
    }

    private void refreshState(class_1308 mob, AggroState state, long currentTick) {
        state.evaluatedTick = currentTick;

        class_1309 target = mob.method_5968();
        if (target != null && target.method_5805()) {
            state.lastAggroTick = currentTick;
            state.targetPlayerUuid = target instanceof class_3222 targetPlayer
                    ? targetPlayer.method_5667()
                    : null;
            state.visible = true;
            return;
        }

        if (state.lastAggroTick != Long.MIN_VALUE
                && currentTick - state.lastAggroTick <= config.lingerTicks) {
            state.visible = true;
            return;
        }

        state.targetPlayerUuid = null;
        state.visible = false;
    }

    private boolean shouldHideFromNonTargetedPlayer(class_3222 player, UUID targetPlayerUuid) {
        return config.showOnlyToTargetedPlayer
                && targetPlayerUuid != null
                && !targetPlayerUuid.equals(player.method_5667());
    }

    private static final class AggroState {
        private long evaluatedTick = Long.MIN_VALUE;
        private long lastAggroTick = Long.MIN_VALUE;
        private UUID targetPlayerUuid;
        private boolean visible;
    }
}
